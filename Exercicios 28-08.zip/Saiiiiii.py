vet = []
for i in range(0,5):
    vet.append(input('Informe a nota: '))

for i in range(0,5):
    print(vet[i])

print(vet)