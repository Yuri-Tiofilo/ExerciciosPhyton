def valorPagamento():
    n = 0
def entradaDados():
    valor = int(input('Digite o valor das parcelas'))