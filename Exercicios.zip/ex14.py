raio = int(input('digite o valor do raio: '))
import math
volume = 1.3*(math.pi*raio**3)
print('%.2f' % volume)
