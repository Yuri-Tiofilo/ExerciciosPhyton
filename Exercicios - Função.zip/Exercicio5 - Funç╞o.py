def exercicio_cinco(vet):
    while 